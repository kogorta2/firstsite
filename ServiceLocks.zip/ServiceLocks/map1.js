ymaps.ready()
    .done(function (ym) {


        var myMap = new ym.Map('YMapsID', {
                center: [37.573856, 55.751574],
                zoom: 10
            }, {
                searchControlProvider: 'yandex#search'
            }),


            yellowCollection = new ymaps.GeoObjectCollection(null, {
                // preset: 'islands#yellowIcon'
            }),

            BalloonContentLayout = ymaps.templateLayoutFactory.createClass(
                '<div style="margin: 10px;">' +
                '<b>{{properties.name}}</b><br />' +
                '<i id="count"></i> ' +
                '<button id="counter-button"> +1 </button>' +
                '</div>', {

                    // Переопределяем функцию build, чтобы при создании макета начинать
                    // слушать событие click на кнопке-счетчике.
                    build: function () {
                        // Сначала вызываем метод build родительского класса.
                        BalloonContentLayout.superclass.build.call(this);
                        // А затем выполняем дополнительные действия.
                        $('#counter-button').bind('click', this.onCounterClick);
                        $('#count').html(counter);
                    },

                    // Аналогично переопределяем функцию clear, чтобы снять
                    // прослушивание клика при удалении макета с карты.
                    clear: function () {
                        // Выполняем действия в обратном порядке - сначала снимаем слушателя,
                        // а потом вызываем метод clear родительского класса.
                        $('#counter-button').unbind('click', this.onCounterClick);
                        BalloonContentLayout.superclass.clear.call(this);
                    },

                    onCounterClick: function () {
                        $('#count').html(++counter);
                        if (counter == 5) {
                            alert('Вы славно потрудились.');
                            counter = 0;
                            $('#count').html(counter);
                        }
                    }
                }),

            min1 = 37.00,
            max1 = 37.60,
            random1 = Math.floor(Math.random() * (+max1 - +min1)) + +min1,

            min2 = 55.00,
            max2 = 55.60,
            random2 = Math.floor(Math.random() * (+max2 - +min2)) + +min2,
            n = 0;

        document.addEventListener("blur", function () {
            n = document.getElementById("demo").value;
            for (let i = 0; i < n; i++) {
                yellowCollection.add(new ymaps.Placemark([random1, random2], {
                    name: 'Введите:'
                },{
                    balloonContentLayout: BalloonContentLayout,
                    balloonPanelMaxMapArea: 0
                },{
                    hintContent: 'Адрес-' + i,
                    // balloonContent: 'Мастер-' + i
                }, {
                    iconLayout: 'default#image',
                    iconImageHref: 'images/guest.png',
                    iconImageSize: [30, 42]

                }));
            }


        });

        myMap.geoObjects.add(yellowCollection);


        // myPlacemark1.events.add('click', function (e) {
        //     funt(0);
        // });
        // myPlacemark2.events.add('click', function (e) {
        //     funt(1);
        // });
        // myPlacemark3.events.add('click', function (e) {
        //     funt(2);
        // });
        // myPlacemark4.events.add('click', function (e) {
        //     funt(3);
        // });
        // myPlacemark5.events.add('click', function (e) {
        //     funt(4);
        // });
        // myPlacemark6.events.add('click', function (e) {
        //     funt(5);
        // });
        // myPlacemark7.events.add('click', function (e) {
        //     funt(6);
        // });
        // myPlacemark8.events.add('click', function (e) {
        //     funt(7);
        // });
        //
        //
        // function funt(a) {
        //     console.log(a);
        //     var elems = document.getElementsByClassName('tab');
        //     console.log(elems);
        //     var element = elems[a];
        //     console.log(element);
        //     [].forEach.call(elems, function (el) {
        //         el.classList.remove("active");
        //     });
        //     element.classList.add('active');
        // }

    })
;