ymaps.ready()
    .done(function (ym) {


        var myMap2 = new ym.Map('YMapsID2', {
            center: [37.573856, 55.751574],
            zoom: 10
        }, {
            searchControlProvider: 'yandex#search'
        });




        MyIconContentLayout = ymaps.templateLayoutFactory.createClass(
            '<div style="color: #FFFFFF; font-weight: bold;">$[properties.iconContent]</div>'
        ),

            myPlacemark1 = new ymaps.Placemark([37.7837, 55.7852], {
                hintContent: 'Адрес-организации',
                balloonContent: 'АДРЕС-1'
            }, {
                iconLayout: 'default#image',
                iconImageHref: 'images/GeoSpot.png',
                iconImageSize: [30, 42]

            }),

            myMap2.geoObjects
                .add(myPlacemark1);


    })
;