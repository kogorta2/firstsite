$(document).ready(function () {

    // $('.slider-item').slick({
    //         slidesToShow: 1,
    //         slidesToScroll: 1,
    //         arrows: true,
    //         prevArrow: $('.prev-arrow'),
    //         nextArrow: $('.next-arrow'),
    //         dots: false,
    //         mobileFirst: true,
    //         focusOnSelect: false,
    //         centerMode: true,
    //         centerPadding: "0",
    //         adaptiveHeight: true,
    //         responsive: [
    //             {
    //                 breakpoint: 478,
    //                 settings: {
    //                     slidesToShow: 3,
    //                     slidesToScroll: 3
    //                 }
    //             }
    //             ,
    //             {
    //                 breakpoint: 638,
    //                 settings: {
    //                     slidesToShow: 3,
    //                     slidesToScroll: 3
    //                 }
    //             }
    //             ,
    //             {
    //                 breakpoint: 767,
    //                 settings: {
    //                     slidesToShow: 3,
    //                     slidesToScroll: 3
    //                 }
    //             }
    //         ]
    //     }
    // );


    $(".first-screen, .content-1, .content-3").on("mousemove",

        function (e) {

            let offset = $(this).offset();
            let xPos = e.pageX - offset.left;
            let yPos = e.pageY - offset.top;
            let mouseXPercent = Math.round(xPos / $(this).width() * 100);
            let mouseYPercent = Math.round(yPos / $(this).height() * 100);

            $(this).find('.parallax').each(
                function () {
                    // let myZ = (mouseXPercent / 1500)*30;
                    let myX = (mouseXPercent / 1500) * 10;
                    let myY = (mouseYPercent / 1080) * 10;
                    // let myY = 0;

                    if ($('.parallax').hasClass('content-3-back')) {
                        $(this).css({"transform": "translate(" + myX + "%," + myY + "%)  skewY(5deg)"}, {
                            duration: 50,
                            queue: false,
                            easing: 'linear'
                        });
                        $(this).css({"perspective": "" + myX + "%"}, {duration: 50, queue: false, easing: 'linear'});
                    } else {
                        $(this).css({"transform": "translate(" + myX + "%," + myY + "%)"}, {
                            duration: 50,
                            queue: false,
                            easing: 'linear'
                        });
                        $(this).css({"perspective": "" + myX + "%"}, {duration: 50, queue: false, easing: 'linear'});
                    }

                }
            );
            $(this).find('.parallax-cover').each(
                function () {
                    let myX = (mouseXPercent / 1500) * 50;
                    // let myY = (mouseYPercent / 1080)*5;
                    let myY = 0;

                    $(this).css({"transform": "translate(" + myX + "%," + myY + "%)"}, {
                        duration: 50,
                        queue: false,
                        easing: 'linear'
                    }, {"transform-origin": "0% 0%"});
                }
            );
        }
    );


    // $(window).scroll(function () {
    //     if ($(window).scrollTop() !== 0) {
    //         $('header').addClass('active');
    //     } else {
    //         $('header').removeClass('active');
    //     }
    // });

    $('.content-2 .ion-ios-arrow-down').on('click', function () {
        $(this).closest('.select').toggleClass('active');
        $(this).closest('.select').find('.option-wrap').toggleClass('active');

    });

    $('.preview').on('click', function () {
        $(this).addClass('active');
    });


    $('.ba-slider').each(function () {
        var cur = $(this);
        // Adjust the slider
        var width = cur.width() + 'px';
        cur.find('.resize img').css('width', width);
        // Bind dragging events
        drags(cur.find('.handle'), cur.find('.resize'), cur);
    });


// Update sliders on resize.
// Because we all do this: i.imgur.com/YkbaV.gif
    $(window).resize(function () {
        $('.ba-slider').each(function () {
            var cur = $(this);
            var width = cur.width() + 'px';
            cur.find('.resize img').css('width', width);
        });
    });

    function drags(dragElement, resizeElement, container) {

        // Initialize the dragging event on mousedown.
        dragElement.on('mousedown touchstart', function (e) {

            dragElement.addClass('draggable');
            resizeElement.addClass('resizable');

            // Check if it's a mouse or touch event and pass along the correct value
            var startX = (e.pageX) ? e.pageX : e.originalEvent.touches[0].pageX;

            // Get the initial position
            var dragWidth = dragElement.outerWidth(),
                posX = dragElement.offset().left + dragWidth - startX,
                containerOffset = container.offset().left,
                containerWidth = container.outerWidth();

            // Set limits
            minLeft = containerOffset + 10;
            maxLeft = containerOffset + containerWidth - dragWidth - 10;

            // Calculate the dragging distance on mousemove.
            dragElement.parents().on("mousemove touchmove", function (e) {

                // Check if it's a mouse or touch event and pass along the correct value
                var moveX = (e.pageX) ? e.pageX : e.originalEvent.touches[0].pageX;

                leftValue = moveX + posX - dragWidth;

                // Prevent going off limits
                if (leftValue < minLeft) {
                    leftValue = minLeft;
                } else if (leftValue > maxLeft) {
                    leftValue = maxLeft;
                }

                // Translate the handle's left value to masked divs width.
                widthValue = (leftValue + dragWidth / 2 - containerOffset) * 100 / containerWidth + '%';

                // Set the new values for the slider and the handle.
                // Bind mouseup events to stop dragging.
                $('.draggable').css('left', widthValue).on('mouseup touchend touchcancel', function () {
                    $(this).removeClass('draggable');
                    resizeElement.removeClass('resizable');
                });
                $('.resizable').css('width', widthValue);
            }).on('mouseup touchend touchcancel', function () {
                dragElement.removeClass('draggable');
                resizeElement.removeClass('resizable');
            });
            e.preventDefault();
        }).on('mouseup touchend touchcancel', function (e) {
            dragElement.removeClass('draggable');
            resizeElement.removeClass('resizable');
        });
    }


//-----------------------------------------                   --------------------------------------------------------


    $('.pop-up-form .cover').on('click', function () {
        $(this).closest('.pop-up-form').addClass('passive');
        console.log($(this).prev('.pop-up-form'));
    });


    $('.close-mobile-menu').on('click', function () {
        $('.mob_menu').removeClass('active');

    });


    $('.menu-item').on('click', function () {
        $('.menu-list i').removeClass('active');
        $('.sub-menu-list.active').removeClass('active');
    });


    $('.sub-menu-item').on('click', function () {
        $(this).next('.sub-menu-list').toggleClass('active');
        $(this).find('i').toggleClass('active');
    })


});
